// FLOW HQ server: the API (BFF) + the built web app, one process. Run behind HTTPS (Caddy) in production.
import { serve } from '@hono/node-server';
import { serveStatic } from '@hono/node-server/serve-static';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';
import { Hono } from 'hono';
import { createApp } from './app';
import { loadConfig } from './config';
import { hashPassword, loadUsers, type UserRecord } from './auth';
import { ProfileStore } from './profiles';
import { createAutopilotAdapter } from './adapters/autopilot';
import { memoryGrist } from './grist';
import { demoDocs } from './demo/fixtures';
import { startStaffReplySimulator } from './demo/simulator';

export function buildServer(env: NodeJS.ProcessEnv = process.env) {
  const cfg = loadConfig(env);
  let adapter;
  let profiles: ProfileStore;
  let users: UserRecord[];
  if (cfg.demo) {
    const { docs, profiles: seed } = demoDocs(Date.now());
    const mem = memoryGrist(docs);
    adapter = createAutopilotAdapter({ gristBaseUrl: 'http://memory', gristApiKey: '', registryDocId: 'REGISTRY', timezone: cfg.timezone, locale: cfg.locale, currency: cfg.currency, fetchImpl: mem, cacheMs: 1000 });
    profiles = new ProfileStore(null, cfg.defaultIndustry, seed);
    users = [
      { email: 'admin@flowhq.demo', name: 'Alex (admin)', role: 'admin', workspaces: ['*'], passwordHash: hashPassword('demo1234') },
      { email: 'staff@flowhq.demo', name: 'Sam', role: 'staff', workspaces: ['*'], passwordHash: hashPassword('demo1234') },
    ];
    startStaffReplySimulator(docs);
  } else {
    adapter = createAutopilotAdapter({ gristBaseUrl: cfg.grist.baseUrl, gristApiKey: cfg.grist.apiKey, registryDocId: cfg.grist.registryDocId, leadsTable: cfg.grist.leadsTable, timezone: cfg.timezone, locale: cfg.locale, currency: cfg.currency });
    profiles = new ProfileStore(cfg.workspacesFile, cfg.defaultIndustry);
    users = loadUsers(cfg.usersFile, cfg.usersJson);
    if (!users.length) throw new Error('No FLOW HQ users: create config/users.json (see README) or set FLOWHQ_USERS');
  }
  const api = createApp({ adapter, profiles, users, sessionSecret: cfg.sessionSecret, secureCookies: cfg.secureCookies, demo: cfg.demo });
  const root = new Hono();
  root.use('*', async (c, next) => {
    await next();
    c.header('X-Frame-Options', 'DENY');
    c.header('X-Content-Type-Options', 'nosniff');
    c.header('Referrer-Policy', 'same-origin');
    c.header('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    c.header('Content-Security-Policy', "default-src 'self'; img-src 'self' data: https:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
  });
  root.route('/', api);
  if (existsSync(cfg.staticDir)) {
    root.use('/assets/*', serveStatic({ root: path.relative(process.cwd(), cfg.staticDir) }));
    root.get('/favicon.svg', serveStatic({ path: path.relative(process.cwd(), path.join(cfg.staticDir, 'favicon.svg')) }));
    const index = readFileSync(path.join(cfg.staticDir, 'index.html'), 'utf8');
    root.get('*', (c) => c.html(index));
  }
  return { app: root, cfg };
}

if (process.argv[1] && /index\.(ts|js)$/.test(process.argv[1])) {
  const { app, cfg } = buildServer();
  serve({ fetch: app.fetch, port: cfg.port }, (i) => console.log(`FLOW HQ on http://localhost:${i.port}${cfg.demo ? ' (DEMO data)' : ''}`));
}
